<?php

$connection = mysqli_connect('localhost','root','','hospital');

if(isset($_POST['delete'])){
    $id=$_POST['delete'];
    $query="DELETE FROM patient_contactdetails WHERE ContactDetails= '$id'";
    if(mysqli_query($connection,$query));{
      echo ("<script>
      alert('The patient_contact deleted successfully !');
      window.location.href='patient_contact.php';
      </script>"); 
  die;
    }
 
 
 }


 if(isset($_POST['update'])){
    $ContactDetails = $_POST['ContactDetails'];
    $ID = $_POST['PatientID'];
   $query="UPDATE patient_contactdetails SET ContactDetails='$ContactDetails' WHERE PatientID='$ID' ";
   if(mysqli_query($connection,$query));{
      echo ("<script>
      alert('The patient_contact updated successfully !');
      window.location.href='patient_contact.php';
      </script>"); 
  die;
   }
}


if(isset($_POST['send'])){
    $ContactDetails = $_POST['ContactDetails'];
    $ID = $_POST['PatientID'];

   if(mysqli_query($connection,"insert into patient_contactdetails(ContactDetails,PatientID) values('$ContactDetails','$ID')"));{
      echo ("<script>
      alert('The new patient_contact added successfully !');
      window.location.href='patient_contact.php';
      </script>"); 
  die;
   }
  
}

?>