<?php

$connection = mysqli_connect('localhost','root','','hospital');


if(isset($_POST['delete'])){
    $id=$_POST['delete'];
    $query="DELETE FROM admission WHERE AdmissionID= '$id'";
    if(mysqli_query($connection,$query));{
      echo ("<script>
      alert('The admission deleted successfully !');
      window.location.href='Admission.php';
      </script>"); 
  die;
    }
 
 
 }


 if(isset($_POST['update'])){
    $ID = $_POST['ID'];
    $Date = $_POST['Date'];
   $ReaExpectedDischargeDate = $_POST['ReaExpectedDischargeDate'];
   $Reason = $_POST['Reason'];
   $PatientID = $_POST['PatientID'];
   $RoomNumber = $_POST['RoomNumber'];
   $OperationTheaterNumber = $_POST['OperationTheaterNumber'];
   $ICUNumber = $_POST['ICUNumber'];
   $query="UPDATE admission SET AdmissionDate='$Date',Expected_DischargeDate='$ReaExpectedDischargeDate',Reason='$Reason',PatientID='$PatientID',RoomNumber='$RoomNumber',OperationTheaterNumber='$OperationTheaterNumber',ICUNumber='$ICUNumber' WHERE AdmissionID='$ID' ";
   if(mysqli_query($connection,$query));{
      echo ("<script>
      alert('The admission updated successfully !');
      window.location.href='Admission.php';
      </script>"); 
  die;
   }


}



if(isset($_POST['send'])){
   $ID = $_POST['ID'];
    $Date = $_POST['Date'];
   $ReaExpectedDischargeDate = $_POST['ReaExpectedDischargeDate'];
   $Reason = $_POST['Reason'];
   $PatientID = $_POST['PatientID'];
   $RoomNumber = $_POST['RoomNumber'];
   $OperationTheaterNumber = $_POST['OperationTheaterNumber'];
   $ICUNumber = $_POST['ICUNumber'];

   if(mysqli_query($connection,"insert into admission(AdmissionID,AdmissionDate,Expected_DischargeDate,Reason,PatientID,RoomNumber,OperationTheaterNumber,ICUNumber) values('$ID ','$Date','$ReaExpectedDischargeDate','$Reason','$PatientID','$RoomNumber','$OperationTheaterNumber','$ICUNumber')"));{
      echo ("<script>
      alert('The new admission added successfully !');
      window.location.href='Admission.php';
      </script>"); 
  die;
   }
  
}

?>