<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="project.css">
    <title>ward_boy_contactdetails Information</title>
    
</head>
<body>

    
        <h1>ward_boy_contactdetails Information</h1>
        <a href="Home.php" id="home">Home</a>

        <a href="addward_boy_contact.php"><button id="addBtn">&#43; <!-- Unicode character for plus sign --></button></a>

    <input type="text" id="searchInput" placeholder="Search for Ward_BoyID...">

    <table id="Table">
        <thead>
            <tr>
                <th>ContactDetails</th>
                <th>Ward_BoyID</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
        <?php
        $connection = mysqli_connect('localhost','root','','hospital');
         $query="SELECT * FROM `ward_boy_contactdetails`";
         $query_run=mysqli_query($connection,$query);
           if(mysqli_num_rows($query_run)>0){
             foreach($query_run as $con){
                // echo $patient['ID'];
                ?>
                <tr>
                  <td><?= $con['ContactDetails'];?> </td>
                  <td><?= $con['Ward_BoyID'];?> </td>
                  
                 
                  <td>
                  <a href="editward_boy_contact.php?id=<?=$con['Ward_BoyID'];?>"><button id="editBtn" >&#9998; <!-- Unicode character for pencil --></button></a>
                  <form action= "connectward_boy_contact.php" method="POST">
                   <button id="deleteBtn" type="Submit" name="delete" value="<?=$con['ContactDetails'];?>" >&#128465; <!-- Unicode character for trash bin --></button>

                   </form>  
                        
                </td>
             </tr>

               <?php 
             }
           }else{
            echo "No record found";
           }
           ?>
        </tbody>
    </table>

    <script>
        
        document.getElementById('searchInput').addEventListener('input', function () {
            var filter = this.value.toUpperCase();
            var table = document.getElementById('Table');
            var rows = table.getElementsByTagName('tr');

            for (var i = 0; i < rows.length; i++) {
                var cells = rows[i].getElementsByTagName('td')[1]; 

                if (cells) {
                    var txtValue = cells.textContent || cells.innerText;

                    if (txtValue.toUpperCase().indexOf(filter) > -1) {
                        rows[i].style.display = '';
                    } else {
                        rows[i].style.display = 'none';
                    }
                }
            }
        });

        
        
    </script>

</body>
</html>
