<?php

$connection = mysqli_connect('localhost','root','','hospital');

if(isset($_POST['delete'])){
    $id=$_POST['delete'];
    $query="DELETE FROM ward_boy_contactdetails WHERE ContactDetails= '$id'";
    if(mysqli_query($connection,$query));{
      echo ("<script>
      alert('The ward_boy_contact deleted successfully !');
      window.location.href='ward_boy_contact.php';
      </script>"); 
  die;
    }
 
 
 }


 if(isset($_POST['update'])){
    $ContactDetails = $_POST['ContactDetails'];
    $ID = $_POST['Ward_BoyID'];
   $query="UPDATE ward_boy_contactdetails SET ContactDetails='$ContactDetails' WHERE Ward_BoyID='$ID' ";
   if(mysqli_query($connection,$query));{
      echo ("<script>
      alert('The ward_boy_contact updated successfully !');
      window.location.href='ward_boy_contact.php';
      </script>"); 
  die;
   }
}


if(isset($_POST['send'])){
    $ContactDetails = $_POST['ContactDetails'];
    $ID = $_POST['Ward_BoyID'];

   if(mysqli_query($connection,"insert into ward_boy_contactdetails(ContactDetails,Ward_BoyID) values('$ContactDetails','$ID')"));{
      echo ("<script>
      alert('The new ward_boy_contact added successfully !');
      window.location.href='ward_boy_contact.php';
      </script>"); 
  die;
   }
  
}

?>