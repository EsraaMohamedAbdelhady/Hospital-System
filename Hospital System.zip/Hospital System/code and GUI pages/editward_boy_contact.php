<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="forms.css">
    <title>Document</title>
</head>
<body>
<?php 
     
     if(isset($_GET['id'])){
         $connection = mysqli_connect('localhost','root','','hospital');
         $pati_id=$_GET['id'];
         $query="SELECT * FROM`ward_boy_contactdetails`WHERE Ward_BoyID='$pati_id'";
         $query_run= mysqli_query($connection,$query);
         if(mysqli_num_rows($query_run)>0){
         $ward_boy=mysqli_fetch_array($query_run);
 
         ?>
         <h1 class="po"> Update <span>ward_boy_contactdetails</span> </h1>
  <div class="book">
    <div>
        <img src="images/WhatsApp_Image_2023-12-14_at_10.53.21_PM-removebg-preview.png" alt="">
    </div>
    <div>
        <form action="connectward_boy_contact.php"  method="post" > 
        <input type="text" placeholder="enter Ward_Boy ContactDetails" name="ContactDetails" value="<?=$ward_boy['ContactDetails'];?>">
            <br>
            <br>
        <input type="text" placeholder="enter  Ward_BoyID" name="Ward_BoyID" value="<?=$ward_boy['Ward_BoyID'];?>">
            <br>
            <br>
           
            <input type="submit" value="update" class="btn" name="update"> 
        
            </form>
    </div>
  </div>
  <?php
        }else{
            echo "error";
        }
    }
    ?> 
</body>
</html>