<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="home.css">
    <title>Document</title>
</head>
<body>
    <div style="width: 100%; height: 100%; position: relative; background: #5f8fb7">
        <div style="width: 255px; height: 157px; left: 300px; top: 90px; position: absolute">
            <div style="width: 255px; height: 157px; left: 0px; top: 0px; position: absolute; background: #42739a92; border-radius: 8px"></div>
            <div style="left: 78px; top: 109px; position: absolute; color: black; font-size: 26px; font-family: Montserrat; font-weight: 700; word-wrap: break-word">Patient</div>
            <img style="width: 90px; height: 77.28px; left: 82px; top: 22px; position: absolute" src="images/image 13 .png " />
        </div>
        <div style="width: 255px; height: 157px; left: 300px; top: 302px; position: absolute">
            <div style="width: 255px; height: 157px; left: 0px; top: 0px; position: absolute; background: #42739a92; border-radius: 8px"></div>
            <div style="left: 49px; top: 109px; position: absolute; color: black; font-size: 26px; font-family: Montserrat; font-weight: 700; word-wrap: break-word">Admissions</div>
            <img style="width: 80px; height: 80px; left: 88px; top: 23px; position: absolute" src="images/Doctor .png" />
        </div>
        <div style="width: 255px; height: 157px; left: 300px; top: 510px; position: absolute">
            <div style="width: 255px; height: 157px; left: 0px; top: 0px; position: absolute; background: #42739a92; border-radius: 8px"></div>
            <div style="left: 83px; top: 115px; position: absolute; color: black; font-size: 26px; font-family: Montserrat; font-weight: 700; word-wrap: break-word">Nurse</div>
            <img style="width: 80px; height: 80px; left: 88px; top: 23px; position: absolute;" src="images/Doctor .png" />
        </div>
       
        <div style="width: 255px; height: 157px; left: 1155px; top: 90px; position: absolute">
            <div style="width: 255px; height: 157px; left: 0px; top: 0px; position: absolute; background: #42739a92; border-radius: 8px"></div>
            <div style="left: 56px; top: 109px; position: absolute; color: black; font-size: 26px; font-family: Montserrat; font-weight: 700; word-wrap: break-word">Treatment</div>
            <img style="width: 80px; height: 80px; left: 88px; top: 26px; position: absolute" src="images/Appointment .png" />
        </div>
        <div style="width: 255px; height: 157px; left: 1155px; top: 302px; position: absolute">
            <div style="width: 255px; height: 157px; left: 0px; top: 0px; position: absolute; background: #42739a92; border-radius: 8px"></div>
            <div style="left: 58px; top: 109px; position: absolute; color: black; font-size: 26px; font-family: Montserrat; font-weight: 700; word-wrap: break-word">Disease</div>
            <img style="width: 80px; height: 80px; left: 88px; top: 23px; position: absolute" src="images/Treatment .png" />
        </div>
        <div style="width: 255px; height: 157px; left: 877px; top: 96px; position: absolute">
            <div style="width: 255px; height: 157px; left: 0px; top: 0px; position: absolute; background: #42739a92; border-radius: 8px"></div>
            <div style="left: 80px; top: 109px; position: absolute; color: black; font-size: 26px; font-family: Montserrat; font-weight: 700; word-wrap: break-word">Operation</div>
            <img style="width: 80px; height: 80px; left: 88px; top: 26px; position: absolute" src="images/Admissions .png" />
        </div>
        <div style="width: 255px; height: 157px; left: 600px; top: 509px; position: absolute">
            <div style="width: 255px; height: 157px; left: 0px; top: 0px; position: absolute; background: #42739a92; border-radius: 8px"></div>
            <div style="left: 102px; top: 112px; position: absolute; color: black; font-size: 26px; font-family: Montserrat; font-weight: 700; word-wrap: break-word">Bill</div>
            <img style="width: 80px; height: 80px; left: 88px; top: 26px; position: absolute" src="images/Admissions .png" />
        </div>
        <div style="width: 255px; height: 157px; left: 870px; top: 302px; position: absolute">
            <div style="width: 255px; height: 157px; left: 0px; top: 0px; position: absolute; background: #42739a92; border-radius: 8px"></div>
            <div style="left: 68px; top: 113px; position: absolute; color: black; font-size: 26px; font-family: Montserrat; font-weight: 700; word-wrap: break-word">Ward Boy</div>
            <img style="width: 80px; height: 80px; left: 95px; top: 23px; position: absolute" src="images/Room .png" />
        </div>
        <div style="width: 467px; height: 526px; left: 373px; top: 90px; position: absolute">
            <div style="width: 255px; height: 157px; left: 212px; top: 0px; position: absolute; background: #42739a92; border-radius: 8px"></div>
            <div style="left: 293px; top: 109px; position: absolute; color: black; font-size: 26px; font-family: Montserrat; font-weight: 700; word-wrap: break-word">Doctor</div>
            <img style="width: 90px; height: 90px; left: 293px; top: 16px; position: absolute" src="images/Stay Details .png" />
            
        </div>
        <div style="width: 255px; height: 157px; left: 585px; top: 302px; position: absolute">
            <div style="width: 255px; height: 157px; left: 0px; top: 0px; position: absolute; background: #42739a92; border-radius: 8px"></div>
            <div style="left: 87px; top: 109px; position: absolute; color: black; font-size: 26px; font-family: Montserrat; font-weight: 700; word-wrap: break-word">Room</div>
            <img style="width: 80px; height: 80px; left: 88px; top: 23px; position: absolute" src="images/Stay Details .png" />
        </div>
        <div style="width: 255px; height: 157px; left: 870px; top: 510px; position: absolute ">
            <div style="width: 255px; height: 157px; left: 0px; top: 0px; position: absolute; background: #42739a92; border-radius: 8px"></div>
            <div style="left: 87px; top: 109px; position: absolute; color: black; font-size: 26px; font-family: Montserrat; font-weight: 700; word-wrap: break-word">ICU</div>
            <img style="width: 80px; height: 80px; left: 88px; top: 23px; position: absolute" src="images/Appointment .png" />
        </div>
        <div style="width: 255px; height: 157px; left: 1160px; top: 510px; position: absolute;align-items: center;">
            <div style="width: 255px; height: 157px; left: 0px; top: 0px; position: absolute; background: #42739a92; border-radius: 8px"></div>
            <div style="left: 80px; top: 109px; position: absolute; color: black; font-size: 26px; font-family: Montserrat; font-weight: 700; word-wrap: break-word">Assist</div>
            <img style="width: 80px; height: 80px; left: 88px; top: 26px; position: absolute" src="images/Appointment .png" />
        </div>
        <div style="width: 255px; height: 157px; left: 300px; top: 700px; position: absolute">
            <div style="width: 255px; height: 157px; left: 0px; top: 0px; position: absolute; background: #42739a92; border-radius: 8px"></div>
            <div style="left: 78px; top: 109px; position: absolute; color: black; font-size: 26px; font-family: Montserrat; font-weight: 700; word-wrap: break-word">cares for</div>
            <img style="width: 90px; height: 77.28px; left: 82px; top: 22px; position: absolute" src="images/image 13 .png" />
        </div>
        <div style="width: 467px; height: 526px; left: 373px; top: 700px; position: absolute">
            <div style="width: 255px; height: 157px; left: 212px; top: 0px; position: absolute; background: #42739a92; border-radius: 8px"></div>
            <div style="left: 277px; top: 109px; position: absolute; color: black; font-size: 26px; font-family: Montserrat; font-weight: 700; word-wrap: break-word">doctorContact</div>
            <img style="width: 90px; height: 90px; left: 293px; top: 16px; position: absolute" src="images/Stay Details .png " />
            
        </div>
        <div style="width: 255px; height: 157px; left: 877px; top: 700px; position: absolute">
            <div style="width: 255px; height: 157px; left: 0px; top: 0px; position: absolute; background: #42739a92; border-radius: 8px"></div>
            <div style="left: 36px; top: 109px; position: absolute; color: black; font-size: 26px; font-family: Montserrat; font-weight: 700; word-wrap: break-word">nurseContact</div>
            <img style="width: 80px; height: 80px; left: 88px; top: 26px; position: absolute" src="images/Admissions .png" />
        </div>
        <div style="width: 255px; height: 157px; left: 1155px; top: 700px; position: absolute">
            <div style="width: 255px; height: 157px; left: 0px; top: 0px; position: absolute; background: #42739a92; border-radius: 8px"></div>
            <div style="left: 56px; top: 109px; position: absolute; color: black; font-size: 26px; font-family: Montserrat; font-weight: 700; word-wrap: break-word">patientContact</div>
            <img style="width: 80px; height: 80px; left: 88px; top: 26px; position: absolute" src="images/Appointment .png" />
        </div>
        <div style="width: 255px; height: 157px; left: 300px; top: 900px; position: absolute">
            <div style="width: 255px; height: 157px; left: 0px; top: 0px; position: absolute; background: #42739a92; border-radius: 8px"></div>
            <div style="left: 60px; top: 100px; position: absolute; color: black; font-size: 26px; font-family: Montserrat; font-weight: 700; word-wrap: break-word">Treatment medication</div>
            <img style="width: 80px; height: 80px; left: 88px; top: 23px; position: absolute" src="images/Doctor .png" />
        </div>
        <div style="width: 255px; height: 157px; left: 585px; top: 900px; position: absolute">
            <div style="width: 255px; height: 157px; left: 0px; top: 0px; position: absolute; background: #42739a92; border-radius: 8px"></div>
            <div style="left: 25px; top: 109px; position: absolute; color: black; font-size: 26px; font-family: Montserrat; font-weight: 700; word-wrap: break-word">treatmentTestResult</div>
            <img style="width: 80px; height: 80px; left: 88px; top: 23px; position: absolute" src="images/Stay Details .png" />
        </div>
        <div style="width: 255px; height: 157px; left: 870px; top: 900px; position: absolute">
            <div style="width: 255px; height: 157px; left: 0px; top: 0px; position: absolute; background: #42739a92; border-radius: 8px"></div>
            <div style="left: 90px; top: 113px; position: absolute; color: black; font-size: 26px; font-family: Montserrat; font-weight: 700; word-wrap: break-word">treats</div>
            <img style="width: 80px; height: 80px; left: 95px; top: 23px; position: absolute" src="images/Room .png" />
        </div>
        <div style="width: 255px; height: 157px; left: 1155px; top: 900px; position: absolute">
            <div style="width: 255px; height: 157px; left: 0px; top: 0px; position: absolute; background: #42739a92; border-radius: 8px"></div>
            <div style="left: 40px; top: 109px; position: absolute; color: black; font-size: 26px; font-family: Montserrat; font-weight: 700; word-wrap: break-word">wardBoyContact</div>
            <img style="width: 80px; height: 80px; left: 80px; top: 23px; position: absolute" src="images/Treatment .png" />
        </div>
     
        <!-- <div style="width: 1983px; height: 265px; left: -543px; top: 0px; position: absolute">
            <div style="width: 1170px; height: 60px; left: 813px; top: 0px; position: absolute; background: #42739a92"></div>
            <div style="left: 1357px; top: 14px; position: absolute; color: black; font-size: 26px; font-family: Montserrat; font-weight: 700; word-wrap: break-word">Home</div>
            <div style="left: 0px; top: 233px; position: absolute; color: black; font-size: 26px; font-family: Montserrat; font-weight: 700; word-wrap: break-word">Home</div>
        </div> -->
        <div style="width: 270px; height: 900px; left: 0px; top: 9px; position: absolute">
            <!-- <div style="width: 270px; height:1200px; left: 0px; top: 0px; position: absolute; background: #42739a92"></div> -->
            <div style="width: 193px; height: 564px; left: 44px; top: 319px; position: absolute">
                <img style="width: 21px; height: 21px; left: 30px; top: 328px; position: absolute" src="images/Room .png" />
                <img style="width: 21px; height: 21px; left: 30px; top: 369px; position: absolute" src="images/Appointment .png" />
                <img style="width: 21px; height: 21px; left: 31px; top: 276px; position: absolute" src="images/Admissions .png" />
                <img style="width: 21px; height: 21px; left: 29px; top: 410px; position: absolute" src="images/Stay Details .png" />
                <img style="width: 21px; height: 21px; left: 33px; top: 458px; position: absolute" src="images/Discharge .png" />
                <img style="width: 19px; height: 19px; left: 31px; top: 225px; position: absolute" src="images/Treatment .png" />
                <img style="width: 18px; height: 18px; left: 35px; top: 180px; position: absolute" src="images/Appointment .png" />
                <img style="width: 18px; height: 18px; left: 33px; top: 538px; position: absolute" src="images/Doctor .png" />
                <img style="width: 19px; height: 19px; left: 35px; top: 130px; position: absolute" src="images/Treatment .png" />
                <img style="width: 19px; height: 19px; left: 35px; top: 500px; position: absolute" src="images/Admissions .png" />
                <img style="width: 20px; height: 17.17px; left: 38px; top: 86px; position: absolute" src="images/image 13 .png" />
                <img style="width: 18px; height: 18px; left: 33px; top: 566px; position: absolute" src="images/Doctor .png" />
                <img style="width: 21px; height: 21px; left: 31px; top: 600px; position: absolute" src="images/Admissions .png" />
                <img style="width: 19px; height: 19px; left: 31px; top: 640px; position: absolute" src="images/Treatment .png" />
                <img style="width: 20px; height: 17.17px; left: 30px; top: 675px; position: absolute" src="images/image 13 .png" />
                <img style="width: 18px; height: 18px; left: 33px; top: 710px; position: absolute" src="images/Appointment .png" />
                <img style="width: 21px; height: 21px; left: 33px; top: 740px; position: absolute" src="images/Discharge .png" />
                <img style="width: 21px; height: 21px; left: 31px; top: 780px; position: absolute" src="images/Admissions .png" />
                <img style="width: 21px; height: 21px; left: 30px; top: 813px; position: absolute" src="images/Room .png" />
                <img style="width: 19px; height: 19px; left: 31px; top: 845px; position: absolute" src="images/Treatment .png" />
                <div style="width: 193px; height: 41px; left: 0px; top: 0px; position: absolute; background: #5f8fb7; border-radius: 4px"></div>
                <div style="left: 62px; top: 180px; position: absolute; color: black; font-size: 14px; font-family: Montserrat; font-weight: 500; word-wrap: break-word"><a href="OperationTheater.php" style="text-decoration: none;color: black;"> Operation Theater</a></div>
                <div style="left: 70px; top: 230px; position: absolute; color: black; font-size: 14px; font-family: Montserrat; font-weight: 500; word-wrap: break-word"><a href="Treatment.php" style="text-decoration: none;color: black;"> Treatment</a></div>
                <div style="left: 62px; top: 279px; position: absolute; color: black; font-size: 14px; font-family: Montserrat; font-weight: 500; word-wrap: break-word"><a href="Admission.php" style="text-decoration: none;color: black;"> Admissions</a></div>
                <div style="left: 75px; top: 370px; position: absolute; color: black; font-size: 14px; font-family: Montserrat; font-weight: 500; word-wrap: break-word"><a href="ICU.php" style="text-decoration: none;color: black;"> ICU</a></div>
                <div style="left: 73px; top: 330px; position: absolute; color: black; font-size: 14px; font-family: Montserrat; font-weight: 500; word-wrap: break-word"><a href="Room.php" style="text-decoration: none;color: black;"> Room</a></div>
                <div style="left: 62px; top: 416px; position: absolute; color: black; font-size: 14px; font-family: Montserrat; font-weight: 500; word-wrap: break-word"><a href="WardBoy.php" style="text-decoration: none;color: black;"> Ward Boy</a></div>
                <div style="left: 67px; top: 460px; position: absolute; color: black; font-size: 14px; font-family: Montserrat; font-weight: 500; word-wrap: break-word"><a href="Disease.php" style="text-decoration: none;color: black;"> Disease</a></div>
                <div style="left: 70px; top: 500px; position: absolute; color: black; font-size: 14px; font-family: Montserrat; font-weight: 500; word-wrap: break-word"><a href="Nurse.php" style="text-decoration: none;color: black;"> Nurse</a></div>
                <div style="left: 68px; top: 540px; position: absolute; color: black; font-size: 14px; font-family: Montserrat; font-weight: 500; word-wrap: break-word"><a href="Bill.php" style="text-decoration: none;color: black;"> Bill</a></div>
                <div style="left: 70px; top: 135px; position: absolute; color: black; font-size: 14px; font-family: Montserrat; font-weight: 500; word-wrap: break-word"><a href="Doctors.php" style="text-decoration: none;color: black;"> Doctor</a></div>
                <div style="left: 75px; top: 88px; position: absolute; color: black; font-size: 14px; font-family: Montserrat; font-weight: 500; word-wrap: break-word"><a href="patients.php" style="text-decoration: none;color: black;"> Patient</a></div>
                <div style="left: 75px; top: 11px; position: absolute; color: black; font-size: 14px; font-family: Montserrat; font-weight: 500; word-wrap: break-word"><a href="Home.php" style="text-decoration: none;color: black;"> Home</a></div>
                <div style="left: 62px; top: 566px; position: absolute; color: black; font-size: 14px; font-family: Montserrat; font-weight: 500; word-wrap: break-word"><a href="assists.php" style="text-decoration: none;color: black;"> Assist</a></div>
                <div style="left: 62px; top: 600px; position: absolute; color: black; font-size: 14px; font-family: Montserrat; font-weight: 500; word-wrap: break-word"><a href="Cares.php" style="text-decoration: none;color: black;"> cares for</a></div>
                <div style="left: 62px; top: 640px; position: absolute; color: black; font-size: 14px; font-family: Montserrat; font-weight: 500; word-wrap: break-word"><a href="doctor_contact.php" style="text-decoration: none;color: black;"> doctor contact details</a></div>
                <div style="left: 62px; top: 675px; position: absolute; color: black; font-size: 14px; font-family: Montserrat; font-weight: 500; word-wrap: break-word"><a href="nurse_contact.php" style="text-decoration: none;color: black;"> nurse contact details</a></div>
                <div style="left: 62px; top: 710px; position: absolute; color: black; font-size: 14px; font-family: Montserrat; font-weight: 500; word-wrap: break-word"><a href="patient_contact.php" style="text-decoration: none;color: black;"> patient contact details</a></div>
                <div style="left: 62px; top: 744px; position: absolute; color: black; font-size: 14px; font-family: Montserrat; font-weight: 500; word-wrap: break-word"><a href="treatment_medications.php" style="text-decoration: none;color: black;"> Treatment Medications</a></div>
                <div style="left: 62px; top: 782px; position: absolute; color: black; font-size: 14px; font-family: Montserrat; font-weight: 500; word-wrap: break-word"><a href="treatment_testresults.php" style="text-decoration: none;color: black;"> Treatment test results </a></div>
                <div style="left: 62px; top: 816px; position: absolute; color: black; font-size: 14px; font-family: Montserrat; font-weight: 500; word-wrap: break-word"><a href="treats.php" style="text-decoration: none;color: black;"> Treats</a> </div>
                <div style="left: 62px; top: 846px; position: absolute; color: black; font-size: 14px; font-family: Montserrat; font-weight: 500; word-wrap: break-word"><a href="ward_boy_contact.php" style="text-decoration: none;color: black;"> wardBoy Contact Details</a> </div>

                <div  style="width: 19px; height: 17px; left: 41px; top: 11px; position: absolute">
                    <img src="images/Vector .png"  style="width: 19px; height: 17px; left: 0px; top: -0px; position: absolute; "></img>
                </div>
            </div>
            <div style="width: 211.50px; height: 24px; left: 25px; top: 18px; position: absolute">
                <div style="left: 12.50px; top: 0px; position: absolute; color: black; font-size: 20px; font-family: Montserrat; font-weight: 700; word-wrap: break-word">Hospital Data Base</div>
                <div style="width: 23px; height: 0px; left: 0px; top: 0px; position: absolute; transform: rotate(90deg); transform-origin: 0 0; border: 4px #5f8fb7 solid"></div>
            </div>
            <div style="width: 128px; height: 169px; left: 71px; top: 96px; position: absolute">
                <div style="left: 26px; top: 148px; position: absolute; color: black; font-size: 17px; font-family: Montserrat; font-weight: 700; word-wrap: break-word">Sections</div>
                <div style="width: 128px; height: 128px; left: 0px; top: 0px; position: absolute; background: #5f8fb7; border-radius: 9999px"></div>
                <img style="width: 164.25px; height: 145.19px; left: -15px; top: 0px; position: absolute" src="images/WhatsApp_Image_2023-12-16_at_12.51.15_PM-removebg.png" />
            </div>
        </div>
    </div>
</body>
</html>