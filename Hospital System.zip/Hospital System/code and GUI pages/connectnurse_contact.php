<?php

$connection = mysqli_connect('localhost','root','','hospital');

if(isset($_POST['delete'])){
    $id=$_POST['delete'];
    $query="DELETE FROM nurse_contactdetails WHERE ContactDetails= '$id'";
    if(mysqli_query($connection,$query));{
      echo ("<script>
      alert('The nurse_contact deleted successfully !');
      window.location.href='nurse_contact.php';
      </script>"); 
  die;
    }
 
 
 }


 if(isset($_POST['update'])){
    $ContactDetails = $_POST['ContactDetails'];
    $ID = $_POST['NurseID'];
   $query="UPDATE nurse_contactdetails SET ContactDetails='$ContactDetails' WHERE NurseID='$ID' ";
   if(mysqli_query($connection,$query));{
      echo ("<script>
      alert('The nurse_contact updated successfully !');
      window.location.href='nurse_contact.php';
      </script>"); 
  die;
   }
}


if(isset($_POST['send'])){
    $ContactDetails = $_POST['ContactDetails'];
    $ID = $_POST['NurseID'];

   if(mysqli_query($connection,"insert into nurse_contactdetails(ContactDetails,NurseID) values('$ContactDetails','$ID')"));{
      echo ("<script>
      alert('The new nurse_contact added successfully !');
      window.location.href='nurse_contact.php';
      </script>"); 
  die;
   }
  
}

?>