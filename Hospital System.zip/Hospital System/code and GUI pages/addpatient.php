<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="forms.css">
</head>
<body>
    <h1 class="po"> Add <span>PATIENT</span> </h1>
  <div class="book">
    <div>
        <img src="images/WhatsApp_Image_2023-12-14_at_10.53.21_PM-removebg-preview.png" alt="">
    </div>
    <div>
        <form action="connectpatient.php"  method="post" > 
    
            <input type="text" placeholder="enter Patient ID" name="ID">
            <br>
            <br>
            <input type="text" placeholder="enter your name" name="name">
            <br>
            <br>
            <input type="Date" placeholder="enter your Date of Birth " name="DateofBirth">
            <br>
            <br>
            <input type="text" placeholder="enter your Gender" name="Gender">
            <br>
            <br>
            <input type="text" placeholder="enter your Address" name="Address">
            <br>
            <br>
           
            <input type="submit" value="submit" class="btn" name="send"> 
        
            </form>
    </div>
  </div>

</body>
</html>