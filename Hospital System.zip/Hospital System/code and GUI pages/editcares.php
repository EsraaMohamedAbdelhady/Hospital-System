<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="forms.css">
    <title>Document</title>
</head>
<body>
<?php 
     
     if(isset($_GET['id'])){
         $connection = mysqli_connect('localhost','root','','hospital');
         $cares_id=$_GET['id'];
         $query="SELECT * FROM`cares_for`WHERE PatientID='$cares_id'";
         $query_run= mysqli_query($connection,$query);
         if(mysqli_num_rows($query_run)>0){
         $cares=mysqli_fetch_array($query_run);
 
         ?>
         <h1 class="po"> Update <span>cares_for</span> </h1>
  <div class="book">
    <div>
        <img src="images/WhatsApp_Image_2023-12-14_at_10.53.21_PM-removebg-preview.png" alt="">
    </div>
    <div>
        <form action="connectcares.php"  method="post" > 
        <input type="text" placeholder="enter PatientID" name="ID" value="<?=$cares['PatientID'];?>">
            <br>
            <br>
        <input type="text" placeholder="enter NurseID" name="NurseID" value="<?=$cares['NurseID'];?>">
            <br>
            <br>
            <input type="submit" value="update" class="btn" name="update"> 
        
            </form>
    </div>
  </div>
  <?php
        }else{
            echo "error";
        }
    }
    ?> 
</body>
</html>