<?php

$connection = mysqli_connect('localhost','root','','hospital');

if(isset($_POST['delete'])){
    $id=$_POST['delete'];
    $query="DELETE FROM bill WHERE BillID= '$id'";
    if(mysqli_query($connection,$query));{
      echo ("<script>
      alert('The bill deleted successfully !');
      window.location.href='Bill.php';
      </script>"); 
  die;
    }
 
 
 }


 if(isset($_POST['update'])){
    $ID = $_POST['ID'];
    $Numberofdays = $_POST['Numberofdays'];
    $Amount = $_POST['Amount'];
    $PatientID = $_POST['PatientID'];
   $query="UPDATE bill SET NumberOfDays='$Numberofdays',Amount='$Amount',PatientID='$PatientID' WHERE BillID='$ID' ";
   if(mysqli_query($connection,$query));{
      echo ("<script>
      alert('The bill updated successfully !');
      window.location.href='Bill.php';
      </script>"); 
  die;
   }
}


if(isset($_POST['send'])){
    $ID = $_POST['ID'];
    $Numberofdays = $_POST['Numberofdays'];
   $Amount = $_POST['Amount'];
   $PatientID = $_POST['PatientID'];

   if(mysqli_query($connection,"insert into bill(BillID,NumberOfDays,Amount,PatientID) values('$ID','$Numberofdays','$Amount','$PatientID')"));{
      echo ("<script>
      alert('The new bill added successfully !');
      window.location.href='Bill.php';
      </script>"); 
  die;
   }
  
}

?>