<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="project.css">
    <title>Cares_for Information</title>
    
</head>
<body>

    
        <h1>Cares_for Information</h1>
        <a href="Home.php" id="home">Home</a>

        <a href="addcares.php"><button id="addBtn">&#43; <!-- Unicode character for plus sign --></button></a>

    <input type="text" id="searchInput" placeholder="Search for PatientID...">

    <table id="Table">
        <thead>
            <tr>
                <th>PatientID</th>
                <th>NurseID</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
        <?php
        $connection = mysqli_connect('localhost','root','','hospital');
         $query="SELECT * FROM `cares_for`";
         $query_run=mysqli_query($connection,$query);
           if(mysqli_num_rows($query_run)>0){
             foreach($query_run as $cares){
                ?>
                <tr>
                  <td><?= $cares['PatientID'];?> </td>
                  <td><?= $cares['NurseID'];?> </td>
                 
                 
                  <td>
                  <a href="editcares.php?id=<?=$cares['PatientID'];?>"><button id="editBtn" >&#9998; <!-- Unicode character for pencil --></button></a>
                  <form action= "connectcares.php" method="POST">
                   <button id="deleteBtn" type="Submit" name="delete" value="<?=$cares['PatientID'];?>" >&#128465; <!-- Unicode character for trash bin --></button>

                   </form>  
                        
                </td>
             </tr>

               <?php 
             }
           }else{
            echo "No record found";
           }
           ?>
        </tbody>
    </table>

    <script>
        
        document.getElementById('searchInput').addEventListener('input', function () {
            var filter = this.value.toUpperCase();
            var table = document.getElementById('Table');
            var rows = table.getElementsByTagName('tr');

            for (var i = 0; i < rows.length; i++) {
                var cells = rows[i].getElementsByTagName('td')[0]; 

                if (cells) {
                    var txtValue = cells.textContent || cells.innerText;

                    if (txtValue.toUpperCase().indexOf(filter) > -1) {
                        rows[i].style.display = '';
                    } else {
                        rows[i].style.display = 'none';
                    }
                }
            }
        });

        
        
    </script>

</body>
</html>
