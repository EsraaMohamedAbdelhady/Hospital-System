<?php

$connection = mysqli_connect('localhost','root','','hospital');

if(isset($_POST['delete'])){
    $id=$_POST['delete'];
    $query="DELETE FROM treatment_testresults WHERE TestResults= '$id'";
    if(mysqli_query($connection,$query));{
      echo ("<script>
      alert('The treatment_testresults deleted successfully !');
      window.location.href='treatment_testresults.php';
      </script>"); 
  die;
    }
 
 
 }


 if(isset($_POST['update'])){
    $TestResults = $_POST['TestResults'];
    $ID = $_POST['TreatmentID'];
   $query="UPDATE treatment_testresults SET TestResults='$TestResults' WHERE TreatmentID='$ID' ";
   if(mysqli_query($connection,$query));{
      echo ("<script>
      alert('The treatment_testresults updated successfully !');
      window.location.href='treatment_testresults.php';
      </script>"); 
  die;
   }
}


if(isset($_POST['send'])){
    $TestResults = $_POST['TestResults'];
    $ID = $_POST['TreatmentID'];

   if(mysqli_query($connection,"insert into treatment_testresults(TestResults,TreatmentID) values('$TestResults','$ID')"));{
      echo ("<script>
      alert('The new treatment_testresults added successfully !');
      window.location.href='treatment_testresults.php';
      </script>"); 
  die;
   }
  
}

?>