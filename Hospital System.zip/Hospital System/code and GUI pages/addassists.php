<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="forms.css">
    <title>Document</title>
</head>
<body>
<h1 class="po"> Add <span>Assists</span> </h1>
  <div class="book">
    <div>
        <img src="images/WhatsApp_Image_2023-12-14_at_10.53.21_PM-removebg-preview.png" alt="">
    </div>
    <div>
        <form action="connectassists.php"  method="post" > 
        <input type="text" placeholder="enter PatientID " name="ID">
            <br>
            <br>
        <input type="text" placeholder="enter Ward_BoyID" name="Ward_BoyID">
            <br>
            <br>
            <input type="submit" value="submit" class="btn" name="send"> 
        
            </form>
    </div>
  </div>
</body>
</html>