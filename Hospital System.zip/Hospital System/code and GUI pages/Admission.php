<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="project.css">
    <title>Admission Information</title>
    
</head>
<body>

        <h1>Admission Information</h1>
        <a href="Home.php" id="home">Home</a>
    
        <a href="addadmission.php"><button id="addBtn">&#43; <!-- Unicode character for plus sign --></button></a>

    <input type="text" id="searchInput" placeholder="Search for PatientID...">

    <table id="Table">
        <thead>
            <tr>
                <th>AdmissionID</th>
                <th>AdmissionDate</th>
                <th>Expected_DischargeDate</th>
                <th>Reason</th>
                <th>PatientID</th>
                <th>RoomNumber</th>
                <th>OperationTheaterNumber</th>
                <th>ICUNumber</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
        <?php
        $connection = mysqli_connect('localhost','root','','hospital');
         $query="SELECT * FROM `admission`";
         $query_run=mysqli_query($connection,$query);
           if(mysqli_num_rows($query_run)>0){
             foreach($query_run as $admission){
                // echo $patient['ID'];
                ?>
                <tr>
                  <td><?= $admission['AdmissionID'];?> </td>
                  <td><?= $admission['AdmissionDate'];?> </td>
                  <td><?= $admission['Expected_DischargeDate'];?> </td>
                  <td><?= $admission['Reason'];?> </td>
                  <td><?= $admission['PatientID'];?> </td>
                  <td><?= $admission['RoomNumber'];?> </td>
                  <td><?= $admission['OperationTheaterNumber'];?> </td>
                  <td><?= $admission['ICUNumber'];?> </td>
                  <td>
                  <a href="editadmission.php?id=<?=$admission['AdmissionID'];?>"><button id="editBtn" >&#9998; <!-- Unicode character for pencil --></button></a>
                  <form action= "connectadmission.php" method="POST">
                   <button id="deleteBtn" type="Submit" name="delete" value="<?=$admission['AdmissionID'];?>" >&#128465; <!-- Unicode character for trash bin --></button>
                   </form>  
                        
                </td>
             </tr>

               <?php 
             }
           }else{
            echo "No record found";
           }

              ?>   

        </tbody>
    </table>


    <script>
        document.getElementById('searchInput').addEventListener('input', function () {
            var filter = this.value.toUpperCase();
            var table = document.getElementById('Table');
            var rows = table.getElementsByTagName('tr');

            for (var i = 0; i < rows.length; i++) {
                var cells = rows[i].getElementsByTagName('td')[4]; 

                if (cells) {
                    var txtValue = cells.textContent || cells.innerText;

                    if (txtValue.toUpperCase().indexOf(filter) > -1) {
                        rows[i].style.display = '';
                    } else {
                        rows[i].style.display = 'none';
                    }
                }
            }
        });

    </script>

</body>
</html>
