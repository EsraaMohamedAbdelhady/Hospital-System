<?php

$connection = mysqli_connect('localhost','root','','hospital');
if(isset($_POST['delete'])){
    $id=$_POST['delete'];
    $query="DELETE FROM hospital_room WHERE RoomNumber= '$id'";
    if(mysqli_query($connection,$query));{
        echo ("<script>
        alert('The  Room Deleted successfully !');
        window.location.href='Room.php';
        </script>"); 
   die;
    }
 
 }

if(isset($_POST['update'])){
    $RoomNumber = $_POST['RoomNumber'];
    $Type = $_POST['Type'];
   $query="UPDATE hospital_room SET Type='$Type' WHERE RoomNumber='$RoomNumber'";
   if(mysqli_query($connection,$query));{
    echo ("<script>
    alert('The Room updated successfully !');
    window.location.href='Room.php';
    </script>"); 
die;
   }


}








if(isset($_POST['send'])){
    $RoomNumber = $_POST['RoomNumber'];
   $Type = $_POST['Type'];
   

   if(mysqli_query($connection,"insert into hospital_room(RoomNumber,Type) values('$RoomNumber','$Type')"));{
    echo ("<script>
      alert('The new Room Added successfully !');
      window.location.href='Room.php';
      </script>"); 
 die;
   }
  
}

?>