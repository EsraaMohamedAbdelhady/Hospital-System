<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Our Hospital</title>
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css" integrity="sha512-xh6O/CkQoPOWDdYTDqeRdPCVd1SpvCA9XXcUnZS2FmJNp1coAFzvtCN9BmamE+4aHK8yyUHUSCcJHgXloTyT2A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/brands.min.css" integrity="sha512-+oRH6u1nDGSm3hH8poU85YFIVTdSnS2f+texdPGrURaJh8hzmhMiZrQth6l56P4ZQmxeZzd2DqVEMqQoJ8J89A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/fontawesome.min.css" integrity="sha512-RvQxwf+3zJuNwl4e0sZjQeX7kUa3o82bDETpgVCH2RiwYSZVDdFJ7N/woNigN/ldyOOoKw8584jM4plQdt8bhA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/regular.min.css" integrity="sha512-aNH2ILn88yXgp/1dcFPt2/EkSNc03f9HBFX0rqX3Kw37+vjipi1pK3L9W08TZLhMg4Slk810sPLdJlNIjwygFw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/solid.min.css" integrity="sha512-uj2QCZdpo8PSbRGL/g5mXek6HM/APd7k/B5Hx/rkVFPNOxAQMXD+t+bG4Zv8OAdUpydZTU3UHmyjjiHv2Ww0PA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/solid.min.css" integrity="sha512-uj2QCZdpo8PSbRGL/g5mXek6HM/APd7k/B5Hx/rkVFPNOxAQMXD+t+bG4Zv8OAdUpydZTU3UHmyjjiHv2Ww0PA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/svg-with-js.min.css" integrity="sha512-j+8sk90CyNqD7zkw9+AwhRuZdEJRLFBUg10GkELVu+EJqpBv4u60cshAYNOidHRgyaKNKhz+7xgwodircCS01g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/v4-font-face.min.css" integrity="sha512-hpWf+VbTLvBF+RSSdHLpJg+nchmQ3mk1+y9b/ICJSQdZt9B4v+zgZCsD54GAI8fV7MbFq7FhrdWgzPmxuluwsw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    
    <link rel="stylesheet" href="start.css">
</head>
<body>
    <header class="main-header">
        <div>
        <a class="logo" href="#"> <i class="fas fa-heartbeat"></i> Medcare.</a>
        
        </div>
          <!-- the navigation bar -->
     <nav class="nav">
         <a href="#hom">Home</a>
         <a href="#servv">Services</a>
         <a href="#abt">About</a>
         
     </nav>
    <!-- <img src="bars-solid.svg" width="10px" class="bars"> -->
    
     </header>
     <section class="sec1">
        <div class="home" id="hom">
          <div class="image">
              <img src="images/WhatsApp_Image_2023-12-16_at_12.51.15_PM-removebg.png" >
          </div>
          <div class="content">
              <h3>Stay Safe, Stay Healthy</h3>
              <p>Welcome to Us, where compassionate care meets cutting-edge technology, providing a healing environment dedicated to your well-being and recovery. </p>
              <a href="Home.php"><button class="btn">Lets Start</button></a>
          </div>
      
         </div>
    </section>
    <section id="servv">
        <h1 class="doc head">OUR <span>SERVICES</span></h1>
        <div class="serv">
            <div>
                <i class="fa-solid fa-user-doctor"></i>
                <h1>140+</h1>
                <p>Doctors At Work</p>
            </div>
            <div>
                <i class="fa-solid fa-person"></i>
                <h1>1040+</h1>
                <p>Satisfied Patients</p>
            </div>
            <div>
                <i class="fa-solid fa-bed"></i>
                <h1>500+</h1>
                <p>Bed Facility</p>
            </div>
            <div>
                <i class="fa-solid fa-hospital"></i>
                <h1>80+</h1>
                <p>Available Hospitals</p>
            </div>
        </div>
      </section>
      <section id="abt">
        <h1 class="us"><span class="abo">ABOUT</span> US</h1>
        <div class="about" id="abt">
            <div>
                <img src="images/WhatsApp_Image_2023-12-14_at_10.53.21_PM-removebg-preview.png" width="600px">

            </div>
            <div>
                <h1>We Take Care Of Your Healthy Life</h1>
                <p>we are driven by a commitment to excellence in healthcare. With a legacy of [number] years, our dedicated team of medical professionals strives to provide personalized, compassionate care, leveraging state-of-the-art technology to ensure your well-being.

                </p>
                <!-- <a href="#"><button class="btn">Learn More</button></a> -->
            </div>
            
        </div>
     </section>
    
    
</body>
</html>