<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="forms.css">
    <title>Document</title>
</head>
<body>
<h1 class="po"> Add <span>Admission</span> </h1>
  <div class="book">
    <div>
        <img src="images/WhatsApp_Image_2023-12-14_at_10.53.21_PM-removebg-preview.png" alt="">
    </div>
    <div>
        <form action="connectadmission.php"  method="post" > 
        <input  style=" top: 10px;"type="text" placeholder="enter AdmissionID" name="ID">
            <br>
            <br>
        <input type="Date" placeholder="enter AdmissionDate" name="Date">
            <br>
            <br>
            <input type="Date" placeholder="enter Expected_DischargeDate " name="ReaExpectedDischargeDate">
            <br>
            <br>
            <input type="text" placeholder="enter Reason" name="Reason">
            <br>
            <br>
            <input type="text" placeholder="enter PatientID" name="PatientID">
            <br>
            <br>
            <input type="text" placeholder="enter RoomNumber" name="RoomNumber">
            <br>
            <br>
            <input type="text" placeholder="enter OperationTheaterNumber" name="OperationTheaterNumber">
            <br>
            <br>
            <input type="text" placeholder="enter ICUNumber" name="ICUNumber">
            <br>
            <br>
            <input type="submit" value="submit" class="btn" name="send"> 
        
            </form>
    </div>
  </div>
</body>
</html>