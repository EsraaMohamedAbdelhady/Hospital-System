<?php

$connection = mysqli_connect('localhost','root','','hospital');

if(isset($_POST['delete'])){
    $id=$_POST['delete'];
    $query="DELETE FROM doctor WHERE DoctorID= '$id'";
    if(mysqli_query($connection,$query));{
      echo ("<script>
      alert('The doctor deleted successfully !');
      window.location.href='Doctors.php';
      </script>"); 
  die;
    }
 
 
 }
 if(isset($_POST['update'])){
    $ID = $_POST['ID'];
    $name = $_POST['name'];
   $Specialization = $_POST['Specialization'];
   
   $query="UPDATE doctor SET Name='$name',Specialization='$Specialization' WHERE DoctorID='$ID'";
   if(mysqli_query($connection,$query));{
      echo ("<script>
      alert('The doctor updated successfully !');
      window.location.href='Doctors.php';
      </script>"); 
  die;
   }


}







if(isset($_POST['send'])){
    $ID = $_POST['ID'];
    $name = $_POST['name'];
   $Specialization = $_POST['Specialization'];
   

   if(mysqli_query($connection,"insert into doctor(DoctorID,Name,Specialization) values('$ID','$name','$Specialization')"));{
      echo ("<script>
      alert('The new doctor added successfully !');
      window.location.href='Doctors.php';
      </script>"); 
  die;
   }
  
}

?>