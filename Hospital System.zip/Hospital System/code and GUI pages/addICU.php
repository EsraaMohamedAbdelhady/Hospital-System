<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="forms.css">
    <title>Document</title>
</head>
<body>
<h1 class="po"> Add <span>ICU</span> </h1>
  <div class="book">
    <div>
        <img src="images/WhatsApp_Image_2023-12-14_at_10.53.21_PM-removebg-preview.png" alt="">
    </div>
    <div>
        <form action="connectICU.php"  method="post" > 
    
        <input type="text" placeholder="enter ICU Number" name="ICUNumber">
            <br>
            <br>
            <input type="text" placeholder="enter MonitoringEquipment " name="MonitoringEquipment">
            <br>
            <br> 
            <input type="submit" value="submit" class="btn" name="send"> 
        
            </form>
    </div>
  </div>






<!-- <form action="connectICU.php"  method="post" > 
<input type="text" placeholder="enter ICU Number" name="ICUNumber">
<input type="text" placeholder="enter MonitoringEquipment " name="MonitoringEquipment">
<input type="submit" value="submit" class="btn" name="send"> 
</form> -->
</body>
</html>