<?php

$connection = mysqli_connect('localhost','root','','hospital');

if(isset($_POST['delete'])){
    $id=$_POST['delete'];
    $query="DELETE FROM doctor_contactdetails WHERE ContactDetails= '$id'";
    if(mysqli_query($connection,$query));{
      echo ("<script>
      alert('The doctor_contact deleted successfully !');
      window.location.href='doctor_contact.php';
      </script>"); 
  die;
    }
 
 
 }


 if(isset($_POST['update'])){
    $ContactDetails = $_POST['ContactDetails'];
    $ID = $_POST['DoctorID'];
   $query="UPDATE doctor_contactdetails SET ContactDetails='$ContactDetails' WHERE DoctorID='$ID' ";
   if(mysqli_query($connection,$query));{
      echo ("<script>
      alert('The doctor_contact updated successfully !');
      window.location.href='doctor_contact.php';
      </script>"); 
  die;
   }
}


if(isset($_POST['send'])){
    $ContactDetails = $_POST['ContactDetails'];
    $ID = $_POST['DoctorID'];

   if(mysqli_query($connection,"insert into doctor_contactdetails(ContactDetails,DoctorID) values('$ContactDetails','$ID')"));{
      echo ("<script>
      alert('The new doctor_contact added successfully !');
      window.location.href='doctor_contact.php';
      </script>"); 
  die;
   }
  
}

?>