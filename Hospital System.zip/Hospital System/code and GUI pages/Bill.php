<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="project.css">
    <title>Bill Information</title>
    
</head>
<body>

    
        <h1>Bill Information</h1>
        <a href="Home.php" id="home">Home</a>

        <a href="addBill.php"><button id="addBtn">&#43; <!-- Unicode character for plus sign --></button></a>

    <input type="text" id="searchInput" placeholder="Search for PatientID...">

    <table id="Table">
        <thead>
            <tr>
                <th>BillID</th>
                <th>Number of days</th>
                <th>Amount</th>
                <th>PatientID</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
        <?php
        $connection = mysqli_connect('localhost','root','','hospital');
         $query="SELECT * FROM `bill`";
         $query_run=mysqli_query($connection,$query);
           if(mysqli_num_rows($query_run)>0){
             foreach($query_run as $bill){
                // echo $patient['ID'];
                ?>
                <tr>
                  <td><?= $bill['BillID'];?> </td>
                  <td><?= $bill['NumberOfDays'];?> </td>
                  <td><?= $bill['Amount'];?> </td>
                  <td><?= $bill['PatientID'];?> </td>
                 
                  <td>
                  <a href="editbill.php?id=<?=$bill['BillID'];?>"><button id="editBtn" >&#9998; <!-- Unicode character for pencil --></button></a>
                  <form action= "connectBill.php" method="POST">
                   <button id="deleteBtn" type="Submit" name="delete" value="<?=$bill['BillID'];?>" >&#128465; <!-- Unicode character for trash bin --></button>

                   </form>  
                        
                </td>
             </tr>

               <?php 
             }
           }else{
            echo "No record found";
           }
           ?>
        </tbody>
    </table>

    <script>
        
        document.getElementById('searchInput').addEventListener('input', function () {
            var filter = this.value.toUpperCase();
            var table = document.getElementById('Table');
            var rows = table.getElementsByTagName('tr');

            for (var i = 0; i < rows.length; i++) {
                var cells = rows[i].getElementsByTagName('td')[3]; 

                if (cells) {
                    var txtValue = cells.textContent || cells.innerText;

                    if (txtValue.toUpperCase().indexOf(filter) > -1) {
                        rows[i].style.display = '';
                    } else {
                        rows[i].style.display = 'none';
                    }
                }
            }
        });

        
        
    </script>

</body>
</html>
