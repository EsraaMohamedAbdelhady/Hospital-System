<?php

$connection = mysqli_connect('localhost','root','','hospital');

if(isset($_POST['delete'])){
    $id=$_POST['delete'];
    $query="DELETE FROM treats WHERE PatientID= '$id'";
    if(mysqli_query($connection,$query));{
      echo ("<script>
      alert('The treats deleted successfully !');
      window.location.href='treats.php';
      </script>"); 
  die;
    }
 
 
 }


 if(isset($_POST['update'])){
    $ID = $_POST['ID'];
    $DoctorID = $_POST['DoctorID'];
   
   $query="UPDATE treats SET DoctorID='$DoctorID' WHERE PatientID='$ID' ";
   if(mysqli_query($connection,$query));{
      echo ("<script>
      alert('The treats updated successfully !');
      window.location.href='treats.php';
      </script>"); 
  die;
   }
}


if(isset($_POST['send'])){
    $ID= $_POST['ID'];
    $DoctorID = $_POST['DoctorID'];
   

   if(mysqli_query($connection,"insert into treats(PatientID,DoctorID) values('$ID','$DoctorID')"));{
      echo ("<script>
      alert('The new treats added successfully !');
      window.location.href='treats.php';
      </script>"); 
  die;
   }
  
}

?>