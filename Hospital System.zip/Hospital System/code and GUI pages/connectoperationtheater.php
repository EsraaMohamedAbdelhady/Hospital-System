<?php

$connection = mysqli_connect('localhost','root','','hospital');
if(isset($_POST['delete'])){
    $id=$_POST['delete'];
    $query="DELETE FROM operation_theater WHERE OperationTheaterNumber= '$id'";
    if(mysqli_query($connection,$query));{
        echo ("<script>
        alert('The OperationTheater Deleted successfully !');
        window.location.href='OperationTheater.php';
        </script>"); 
   die;
    }
 
 }


if(isset($_POST['update'])){
    $OperationTheaterNumber = $_POST['OperationTheaterNumber'];
    $SpecialEquipment = $_POST['SpecialEquipment'];
   $query="UPDATE operation_theater SET SpecialEquipment='$SpecialEquipment' WHERE OperationTheaterNumber='$OperationTheaterNumber'";
   if(mysqli_query($connection,$query));{
    echo ("<script>
    alert('The OperationTheater updated successfully !');
    window.location.href='OperationTheater.php';
    </script>"); 
die;
   }


}






if(isset($_POST['send'])){
    $OperationTheaterNumber = $_POST['OperationTheaterNumber'];
   $SpecialEquipment = $_POST['SpecialEquipment'];
   

   if(mysqli_query($connection,"insert into operation_theater(OperationTheaterNumber,SpecialEquipment) values('$OperationTheaterNumber','$SpecialEquipment')"));{
    echo ("<script>
      alert('The new operationtheater Added successfully !');
      window.location.href='OperationTheater.php';
      </script>"); 
 die;
   }
  
}

?>