<?php

$connection = mysqli_connect('localhost','root','','hospital');

if(isset($_POST['delete'])){
    $id=$_POST['delete'];
    $query="DELETE FROM treatment_medications WHERE Medications= '$id'";
    if(mysqli_query($connection,$query));{
      echo ("<script>
      alert('The treatment_medications deleted successfully !');
      window.location.href='treatment_medications.php';
      </script>"); 
  die;
    }
 
 
 }


 if(isset($_POST['update'])){
    $Medications = $_POST['Medications'];
    $ID = $_POST['TreatmentID'];
   $query="UPDATE treatment_medications SET Medications='$Medications' WHERE TreatmentID='$ID' ";
   if(mysqli_query($connection,$query));{
      echo ("<script>
      alert('The treatment_medications updated successfully !');
      window.location.href='treatment_medications.php';
      </script>"); 
  die;
   }
}


if(isset($_POST['send'])){
    $Medications = $_POST['Medications'];
    $ID = $_POST['TreatmentID'];

   if(mysqli_query($connection,"insert into treatment_medications(Medications,TreatmentID) values('$Medications','$ID')"));{
      echo ("<script>
      alert('The new treatment_medications added successfully !');
      window.location.href='treatment_medications.php';
      </script>"); 
  die;
   }
  
}

?>