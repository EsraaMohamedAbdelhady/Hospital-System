<?php

$connection = mysqli_connect('localhost','root','','hospital');



// $connection = mysqli_connect('localhost','root','','book_db');

if(isset($_POST['delete'])){
   $id=$_POST['delete'];
   $query="DELETE FROM ward_boy WHERE Ward_BoyID= '$id'";
   if(mysqli_query($connection,$query));{
      echo ("<script>
      alert('The WardBoy Deleted successfully !');
      window.location.href='WardBoy.php';
      </script>"); 
 die;
   }


}



if(isset($_POST['update'])){
    $ID = $_POST['ID'];
    $name = $_POST['name'];
   
   $query="UPDATE ward_boy SET Name='$name' WHERE Ward_BoyID='$ID'";
   if(mysqli_query($connection,$query));{
      echo ("<script>
      alert('The WardBoy Updated successfully !');
      window.location.href='WardBoy.php';
      </script>"); 
 die;
   }


}








if(isset($_POST['send'])){
    $ID = $_POST['ID'];
    $name = $_POST['name'];
   

   if(mysqli_query($connection,"insert into ward_boy(Ward_BoyID,Name) values('$ID','$name')"));{
      echo ("<script>
      alert('The  new WardBoy Added successfully !');
      window.location.href='WardBoy.php';
      </script>"); 
 die;
   }
  
}

?>