<?php

$connection = mysqli_connect('localhost','root','','hospital');

if(isset($_POST['delete'])){
    $id=$_POST['delete'];
    $query="DELETE FROM assists WHERE PatientID= '$id'";
    if(mysqli_query($connection,$query));{
      echo ("<script>
      alert('The assists deleted successfully !');
      window.location.href='assists.php';
      </script>"); 
  die;
    }
 
 
 }


 if(isset($_POST['update'])){
    $ID = $_POST['ID'];
    $Ward_BoyID = $_POST['Ward_BoyID'];
   
   $query="UPDATE assists SET  Ward_BoyID='$Ward_BoyID' WHERE  PatientID='$ID'";
   if(mysqli_query($connection,$query));{
      echo ("<script>
      alert('The assists updated successfully !');
      window.location.href='assists.php';
      </script>"); 
  die;
   }
}


if(isset($_POST['send'])){
    $ID= $_POST['ID'];
    $Ward_BoyID = $_POST['Ward_BoyID'];
   

   if(mysqli_query($connection,"insert into assists(PatientID,Ward_BoyID) values('$ID','$Ward_BoyID')"));{
      echo ("<script>
      alert('The new assists added successfully !');
      window.location.href='assists.php';
      </script>"); 
  die;
   }
  
}

?>