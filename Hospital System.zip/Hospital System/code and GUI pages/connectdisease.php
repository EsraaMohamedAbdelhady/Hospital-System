<?php

$connection = mysqli_connect('localhost','root','','hospital');
if(isset($_POST['delete'])){
    $id=$_POST['delete'];
    $query="DELETE FROM disease WHERE DiseaseID= '$id'";
    if(mysqli_query($connection,$query));{
      echo ("<script>
      alert('The disease deleted successfully !');
      window.location.href='Disease.php';
      </script>"); 
  die;
    }
 
 
 }


 if(isset($_POST['update'])){
    $ID = $_POST['ID'];
   $Description = $_POST['Description'];
   $PatientID = $_POST['PatientID'];
   $query="UPDATE disease SET Description='$Description', PatientID='$PatientID' WHERE DiseaseID='$ID'";
   if(mysqli_query($connection,$query));{
      echo ("<script>
      alert('The disease updated successfully !');
      window.location.href='Disease.php';
      </script>"); 
  die;
   }


}



if(isset($_POST['send'])){
    $ID = $_POST['ID'];
   $Description = $_POST['Description'];
   $PatientID = $_POST['PatientID'];
   if(mysqli_query($connection,"insert into disease(DiseaseID,Description,PatientID) values('$ID','$Description','$PatientID')"));{
      echo ("<script>
      alert('The new disease addded successfully !');
      window.location.href='Disease.php';
      </script>"); 
  die;
   }
  
}

?>