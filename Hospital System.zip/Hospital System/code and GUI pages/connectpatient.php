<?php

$connection = mysqli_connect('localhost','root','','hospital');

if(isset($_POST['delete'])){
   $id=$_POST['delete'];
   $query="DELETE FROM patient WHERE PatientID= '$id'";
   if(mysqli_query($connection,$query));{
      echo ("<script>
      alert('The Patient Deleted successfully !');
      window.location.href='Patients.php';
      </script>"); 
 die;
   }


}








if(isset($_POST['update'])){
   $ID= $_POST['ID'];
   $name= $_POST['name'];
   $DateofBirth= $_POST['DateofBirth'];
   $Gender= $_POST['Gender'];
   $Address= $_POST['Address'];
   $query="UPDATE patient SET FullName='$name',DateOfBirth='$DateofBirth',Gender='$Gender',Address='$Address' WHERE PatientID='$ID'";
   if(mysqli_query($connection,$query));{
      echo ("<script>
      alert('The Patient data UPdated successfully !');
      window.location.href='Patients.php';
      </script>"); 
 die;
   }


}



if(isset($_POST['send'])){
    $ID = $_POST['ID'];
    $name = $_POST['name'];
   $DateofBirth = $_POST['DateofBirth'];
   $Gender = $_POST['Gender'];
   $Address = $_POST['Address'];
  

   if(mysqli_query($connection,"insert into patient(PatientID,FullName,DateOfBirth,Gender,Address) values('$ID','$name','$DateofBirth','$Gender','$Address')"));{
      echo ("<script>
      alert('The new Patient Added successfully !');
      window.location.href='Patients.php';
      </script>"); 
 die;
   }
  
}

?>
