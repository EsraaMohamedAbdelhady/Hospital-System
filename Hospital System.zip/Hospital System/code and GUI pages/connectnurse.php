<?php

$connection = mysqli_connect('localhost','root','','hospital');



if(isset($_POST['delete'])){
   $id=$_POST['delete'];
   $query="DELETE FROM nurse WHERE NurseID= '$id'";
   if(mysqli_query($connection,$query));{
      echo ("<script>
    alert('The nurse deleted successfully !');
    window.location.href='Nurse.php';
    </script>"); 
die;
   }


}


if(isset($_POST['update'])){
    $ID = $_POST['ID'];
    $name = $_POST['name'];
  
   $query="UPDATE nurse SET Name='$name' WHERE NurseID='$ID'";
   if(mysqli_query($connection,$query));{
      echo ("<script>
      alert('The Nurse updated successfully !');
      window.location.href='Nurse.php';
      </script>"); 
  die;
   }


}




if(isset($_POST['send'])){
    $ID = $_POST['ID'];
    $name = $_POST['name'];
   

   if(mysqli_query($connection,"insert into nurse(NurseID,Name) values('$ID','$name')"));{
      echo ("<script>
      alert('The  new nurse added successfully !');
      window.location.href='Nurse.php';
      </script>"); 
  die;
   }
  
}

?>