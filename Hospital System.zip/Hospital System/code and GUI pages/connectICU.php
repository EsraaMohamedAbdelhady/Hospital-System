<?php

$connection = mysqli_connect('localhost','root','','hospital');

if(isset($_POST['delete'])){
    $id=$_POST['delete'];
    $query="DELETE FROM icu WHERE ICUNumber= '$id'";
    if(mysqli_query($connection,$query));{
      echo ("<script>
      alert('The icu deleted successfully !');
      window.location.href='ICU.php';
      </script>"); 
  die;
    }
 
 
 }
 if(isset($_POST['update'])){
    $ICUNumber = $_POST['ICUNumber'];
    $MonitoringEquipment = $_POST['MonitoringEquipment'];
   $query="UPDATE icu SET MonitoringEquipment='$MonitoringEquipment' WHERE ICUNumber='$ICUNumber'";
   if(mysqli_query($connection,$query));{
      echo ("<script>
      alert('The icu updated successfully !');
      window.location.href='ICU.php';
      </script>"); 
  die;
   }


}









if(isset($_POST['send'])){
    $ICUNumber = $_POST['ICUNumber'];
   $MonitoringEquipment = $_POST['MonitoringEquipment'];
   

   if(mysqli_query($connection,"insert into icu(ICUNumber,MonitoringEquipment) values('$ICUNumber','$MonitoringEquipment')"));{
      echo ("<script>
      alert('The  new ICU added successfully !');
      window.location.href='ICU.php';
      </script>"); 
  die;
   }
  
}

?>